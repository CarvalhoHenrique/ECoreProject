package com.ecore.bdd.config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserConfig {
	//Application url
	private String url = "https://automation-sandbox.herokuapp.com/";
	public WebDriver driver;
	
	//Setup method
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
	}
	public WebDriver getCurrentDriver() {
		return driver;
	}
	public void openApplication() {
		driver.get(url);
		driver.manage().window().maximize();
	}
	public void closeApp() {
		driver.quit();
	}
}
