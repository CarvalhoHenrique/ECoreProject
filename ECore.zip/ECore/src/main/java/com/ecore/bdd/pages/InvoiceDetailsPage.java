package com.ecore.bdd.pages;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.ecore.bdd.config.BrowserConfig;

public class InvoiceDetailsPage extends BrowserConfig {
	
	private WebDriver driver;
	private WebElement signOutBtn ;
	private WebElement invoiceDetailsTitle;
	private WebElement hotelNameValue;
	private WebElement invoiceDateValue;
	private WebElement dueDateValue;
	private WebElement invoiceNumberValue;
	private WebElement bookingCodeValue;
	private WebElement customerDetailsValue;
	private WebElement roomValue;
	private WebElement checkInValue;
	private WebElement checkOutValue;
	private WebElement totalStayCountValue;
	private WebElement totalStayAmountValue;
	private WebElement depositNowValue;
	private WebElement taxVatValue;
	private WebElement totalAmountValue;

	//Constructors
	public InvoiceDetailsPage() {}
	public InvoiceDetailsPage(WebDriver driver) {
		this.driver = driver;
		this.signOutBtn = driver.findElement(By.xpath("//nav/ul/li/a"));
		this.invoiceDetailsTitle = driver.findElement(By.xpath("//section/div/header/h2"));
		this.hotelNameValue = driver.findElement(By.xpath("//section/div/h4"));
		this.invoiceDateValue = driver.findElement(By.xpath("//section/div/ul/li[1]"));
		this.dueDateValue = driver.findElement(By.xpath("//section/div/ul/li[2]"));
		this.invoiceNumberValue = driver.findElement(By.xpath("//section/div/h6"));
		this.bookingCodeValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[1]/td[2]"));
		this.customerDetailsValue = driver.findElement(By.xpath("//section/div/div"));
		this.roomValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[2]/td[2]"));
		this.checkInValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[5]/td[2]"));
		this.checkOutValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[6]/td[2]"));
		this.totalStayCountValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[3]/td[2]"));
		this.totalStayAmountValue = driver.findElement(By.xpath("//section/div/table[1]/tbody/tr[4]/td[2]"));
		this.depositNowValue = driver.findElement(By.xpath("//section/div/table[2]/tbody/tr/td[1]"));
		this.taxVatValue = driver.findElement(By.xpath("//section/div/table[2]/tbody/tr/td[2]"));
		this.totalAmountValue = driver.findElement(By.xpath("//section/div/table[2]/tbody/tr/td[3]"));
	}
	
	//Validation methods
	public void validateDetailsPageOpened() {
		boolean status = false;
		if(invoiceDetailsTitle.isDisplayed()) {
			status = true;
		}
		assertTrue("The User was not able to access Invoice Details", status);
	}
	
	public void validateInvoiceDetails(List<String> details) {
		boolean status = false;
		String tVatValue = taxVatValue.getText() +".00";
		String totAmountValue = totalAmountValue.getText() +".00";
		String screenCstmDetails = customerDetailsValue.getText().replace("\n", " ");
	
		if(hotelNameValue.getText().equals(details.get(0))
				&& invoiceDateValue.getText().contains(details.get(1))
				&& dueDateValue.getText().contains(details.get(2))
				&& invoiceNumberValue.getText().contains(details.get(3))
				&& bookingCodeValue.getText().equals(details.get(4))
				&& screenCstmDetails.equals(details.get(5))
				&& roomValue.getText().equals(details.get(6))
				&& checkInValue.getText().equals(details.get(7))
				&& checkOutValue.getText().equals(details.get(8))
				&& totalStayCountValue.getText().equals(details.get(9))
				&& totalStayAmountValue.getText().equals(details.get(10))
				&& depositNowValue.getText().equals(details.get(11))
				&& tVatValue.equals(details.get(12))
				&& totAmountValue.equals(details.get(13))) {
			status = true;
		}
		assertEquals(true, status);
	}
		
	public void logOut() {
		signOutBtn.click();
		driver.quit();
	}
	
	//Setters and Getters
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getSignOutBtn() {
		return signOutBtn;
	}
	public void setSignOutBtn(WebElement signOutBtn) {
		this.signOutBtn = signOutBtn;
	}
	public WebElement getInvoiceDetailsTitle() {
		return invoiceDetailsTitle;
	}
	public void setInvoiceDetailsTitle(WebElement invoiceDetailsTitle) {
		this.invoiceDetailsTitle = invoiceDetailsTitle;
	}
	public WebElement getHotelNameValue() {
		return hotelNameValue;
	}
	public void setHotelNameValue(WebElement hotelNameValue) {
		this.hotelNameValue = hotelNameValue;
	}
	public WebElement getInvoiceDateValue() {
		return invoiceDateValue;
	}
	public void setInvoiceDateValue(WebElement invoiceDateValue) {
		this.invoiceDateValue = invoiceDateValue;
	}
	public WebElement getDueDateValue() {
		return dueDateValue;
	}
	public void setDueDateValue(WebElement dueDateValue) {
		this.dueDateValue = dueDateValue;
	}
	public WebElement getInvoiceNumberValue() {
		return invoiceNumberValue;
	}
	public void setInvoiceNumberValue(WebElement invoiceNumberValue) {
		this.invoiceNumberValue = invoiceNumberValue;
	}
	public WebElement getBookingCodeValue() {
		return bookingCodeValue;
	}
	public void setBookingCodeValue(WebElement bookingCodeValue) {
		this.bookingCodeValue = bookingCodeValue;
	}
	public WebElement getCustomerDetailsValue() {
		return customerDetailsValue;
	}
	public void setCustomerDetailsValue(WebElement customerDetailsValue) {
		this.customerDetailsValue = customerDetailsValue;
	}
	public WebElement getRoomValue() {
		return roomValue;
	}
	public void setRoomValue(WebElement roomValue) {
		this.roomValue = roomValue;
	}
	public WebElement getCheckInValue() {
		return checkInValue;
	}
	public void setCheckInValue(WebElement checkInValue) {
		this.checkInValue = checkInValue;
	}
	public WebElement getCheckOutValue() {
		return checkOutValue;
	}
	public void setCheckOutValue(WebElement checkOutValue) {
		this.checkOutValue = checkOutValue;
	}
	public WebElement getTotalStayCountValue() {
		return totalStayCountValue;
	}
	public void setTotalStayCountValue(WebElement totalStayCountValue) {
		this.totalStayCountValue = totalStayCountValue;
	}
	public WebElement getTotalStayAmountValue() {
		return totalStayAmountValue;
	}
	public void setTotalStayAmountValue(WebElement totalStayAmountValue) {
		this.totalStayAmountValue = totalStayAmountValue;
	}
	public WebElement getDepositNowValue() {
		return depositNowValue;
	}
	public void setDepositNowValue(WebElement depositNowValue) {
		this.depositNowValue = depositNowValue;
	}
	public WebElement getTaxVatValue() {
		return taxVatValue;
	}
	public void setTaxVatValue(WebElement taxVatValue) {
		this.taxVatValue = taxVatValue;
	}
	public WebElement getTotalAmountValue() {
		return totalAmountValue;
	}
	public void setTotalAmountValue(WebElement totalAmountValue) {
		this.totalAmountValue = totalAmountValue;
	}
}
