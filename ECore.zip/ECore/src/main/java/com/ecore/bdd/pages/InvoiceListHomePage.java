package com.ecore.bdd.pages;

import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.ecore.bdd.config.BrowserConfig;

public class InvoiceListHomePage extends BrowserConfig {
	
	private WebDriver driver;
	private WebElement signOutBtn ;
	private WebElement invoiceListTitle;
	private WebElement invoiceDetails;

	//Constructors
	public InvoiceListHomePage() {	}
	public InvoiceListHomePage(WebDriver driver) {
		this.driver = driver;
		this.signOutBtn = driver.findElement(By.xpath("//nav/ul/li/a"));
		this.invoiceListTitle = driver.findElement(By.xpath("//section/div/header/div/div/h2"));
		this.invoiceDetails = driver.findElement(By.xpath("//section/div/div[2]/div[5]/a"));
	}
	
	//Validation methods
	public boolean isLogged() {
		boolean status = false;
		if(invoiceListTitle.isDisplayed()) {
			status = true;
		}
		return status;
	}
	public void validateLogged() {
		boolean status = false;
		if(invoiceListTitle.isDisplayed()) {
			status = true;
		}
		assertTrue("The User is logged as expected", status);
	}
	
	public void openInvoiceDetails() {
		invoiceDetails.click();
		switchTab(1);
	}
	public void switchTab(int tab) {
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(tab));
	}
		
	public void logOut() {
		signOutBtn.click();
		driver.close();
	}
	
	//Setters and Getters
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebDriver getDriver() {
		return driver;
	}
	public WebElement getInvoiceDetails() {
		return invoiceDetails;
	}
	public void setInvoiceDetails(WebElement invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}
	public WebElement getSignOutBtn() {
		return signOutBtn;
	}
	public void setSignOutBtn(WebElement signOutBtn) {
		this.signOutBtn = signOutBtn;
	}
	public WebElement getInvoiceListTitle() {
		return invoiceListTitle;
	}
	public void setInvoiceListTitle(WebElement invoiceListTitle) {
		this.invoiceListTitle = invoiceListTitle;
	}

}
