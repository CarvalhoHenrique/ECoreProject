package com.ecore.bdd.pages;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ecore.bdd.config.BrowserConfig;

public class AutomationExampleApp extends BrowserConfig {
	
	private WebDriver driver;	
	private WebElement loginLabel;
	private WebElement usernameField;
	private WebElement passField;
	private WebElement loginBtn;
	private WebElement signOutBtn ;
	private WebElement wrongUserOrPassMsg;

	//Construtors
	public AutomationExampleApp() {	}
	public AutomationExampleApp(WebDriver driver) {
		this.driver = driver;
		loginLabel = driver.findElement(By.xpath("//div[1]/div/div/h1"));
		this.usernameField = driver.findElement(By.xpath("//div[1]/form/div[1]/div[2]/input"));
		this.passField = driver.findElement(By.xpath("//div[1]/form/div[2]/div[2]/input"));
		this.loginBtn = driver.findElement(By.xpath("//*[@id='btnLogin']"));
		this.wrongUserOrPassMsg = driver.findElement(By.xpath("//div[1]/div[1]"));
	}
	
	//Validation Methods
	public void validateOpenApp() {
		boolean status = false;
		if(loginLabel.isDisplayed()) {
			status = true;
		}
		assertTrue("The application is open on Login page", status);
	}
	
	public void loginApp(String user, String pass) {
		usernameField.sendKeys(user);
		passField.sendKeys(pass);
		loginBtn.click();
	}
	
	public void validateLoginErrorMessage() throws InterruptedException {
		boolean status = false;
		Thread.sleep(3000);
		if(retryFindObject("//div[1]/div[1]")) {
			status = true;
		}
		assertTrue("The application shows 'Wrong username or password' message as expected", status);
	}
	public boolean retryFindObject(String xpath) {
	    boolean result = false;
	    int attempts = 0;
	    while(attempts < 2) {
	        try {
	            if(driver.findElement(By.xpath(xpath)).isDisplayed()){
		            result = true;
		            break;	
	            }
	        } catch(Exception e) {
	        }
	        attempts++;
	    }
	    return result;
	}
	
	public void logOut() {
		signOutBtn.click();
		driver.close();
	}
	
	//Setters and Getters
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebDriver getDriver() {
		return driver;
	}
	public WebElement getLoginLabel() {
		return loginLabel;
	}
	public void setLoginLabel(WebElement loginLabel) {
		this.loginLabel = loginLabel;
	}
	public WebElement getUsernameField() {
		return usernameField;
	}
	public void setUsernameField(WebElement usernameField) {
		this.usernameField = usernameField;
	}
	public WebElement getPassField() {
		return passField;
	}
	public void setPassField(WebElement passField) {
		this.passField = passField;
	}
	public WebElement getLoginBtn() {
		return loginBtn;
	}
	public void setLoginBtn(WebElement loginBtn) {
		this.loginBtn = loginBtn;
	}
	public WebElement getSignOutBtn() {
		return signOutBtn;
	}
	public void setSignOutBtn(WebElement signOutBtn) {
		this.signOutBtn = signOutBtn;
	}
	public WebElement getWrongUserOrPassMsg() {
		return wrongUserOrPassMsg;
	}
	public void setWrongUserOrPassMsg(WebElement wrongUserOrPassMsg) {
		this.wrongUserOrPassMsg = wrongUserOrPassMsg;
	}

}
