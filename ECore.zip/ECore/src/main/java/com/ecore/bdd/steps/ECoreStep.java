package com.ecore.bdd.steps;

import java.util.List;

import com.ecore.bdd.config.BrowserConfig;
import com.ecore.bdd.pages.AutomationExampleApp;
import com.ecore.bdd.pages.InvoiceDetailsPage;
import com.ecore.bdd.pages.InvoiceListHomePage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ECoreStep {
	
	BrowserConfig driver = new BrowserConfig(); 
	AutomationExampleApp app;
	InvoiceListHomePage homePage;
	InvoiceDetailsPage details;
	
	//TC001 - Login (Positive) - User is able to successfully access the application with valid credentials
	@Given("^A user opens Automation Example Application$")
	public void a_user_opens_Automation_Example_Application() throws Throwable {
		driver.setUp();
		app = new AutomationExampleApp(driver.getCurrentDriver());
	    app.validateOpenApp();
	}

	@When("^User inputs valid credentials: user \"([^\"]*)\", pass \"([^\"]*)\"$")
	public void user_inputs_valid_credentials_user_pass(String user, String pass) throws Throwable {
	    app.loginApp(user, pass);
	}

	@Then("^User should be able to successfully access the application$")
	public void user_should_be_able_to_successfully_access_the_application() throws Throwable {
	   homePage = new InvoiceListHomePage(driver.getCurrentDriver());
	   homePage.validateLogged();
	   homePage.logOut();
	}

	//TC002 - Login (Negative) - User is not able to access the application with invalid credentials
	@When("^User inputs invalid credentials: user \"([^\"]*)\", pass \"([^\"]*)\"$")
	public void user_inputs_invalid_credentials_user_pass(String user, String pass) {
		app.loginApp(user, pass);
	}
	
	@Then("^Application shows error message and user should not be able to access the application$")
	public void application_shows_error_message_and_user_should_not_be_able_to_access_the_application() throws Throwable {
		app.validateLoginErrorMessage();
		driver.closeApp();
	}
	
	//TC003 - Validate Invoice Information (Positive) - User is not able to compare input data with Invoice data
	@When("^User inputs invalid credentials$")
	public void user_inputs_invalid_credentials(DataTable cred) throws Throwable {
	    List<String> credentials = cred.asList(String.class);
		app.loginApp(credentials.get(0), credentials.get(1));
	}
	@Then("^User clicks on first Invoice Details and is able to validate its data$")
	public void user_clicks_on_first_Invoice_Details_and_is_able_to_validate_its_data(DataTable data) throws Throwable {
		List<String> invoiceData = data.asList(String.class);
		homePage = new InvoiceListHomePage(driver.getCurrentDriver());
		homePage.openInvoiceDetails();
		details = new InvoiceDetailsPage(driver.getCurrentDriver());
		details.validateDetailsPageOpened();
		details.validateInvoiceDetails(invoiceData);
		details.logOut();
	}	
}
